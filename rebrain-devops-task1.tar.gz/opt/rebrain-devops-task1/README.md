tut lezhit cconfig nginx.conf
